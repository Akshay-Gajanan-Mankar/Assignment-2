// carousel
$('.owl-carousel').owlCarousel({
  items: 1,
  dots: true,
  nav: true,
  smartSpeed: 450,
  margin: 300,
  autoplay: true,
  autoplayTimeout: 10000,
  autoplayHoverPause: true,

  responsive: {
  }
});
